import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Header } from "@/components/header"
import { Testimonials } from "@/components/testimonials"
import { Gallery } from "@/components/gallery"
import { LeaderSection } from "@/components/leader-section"
import { ServicesSection } from "@/components/services-section"
import { FloatingWhatsApp } from "@/components/floating-whatsapp"
import { HeroSection } from "@/components/hero-section"
import { FeatureSection } from "@/components/feature-section"
import { CTASection } from "@/components/cta-section"

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col bg-white">
      <Header />
      <HeroSection />
      <FeatureSection />
      <LeaderSection />
      <ServicesSection />
      <Gallery />
      <Testimonials />
      <CTASection />
      <FloatingWhatsApp />
    </div>
  )
}

