import { ArrowRight, PhoneIcon as WhatsApp } from 'lucide-react';
import { Button, Link } from "@/components/ui/button";
import { Gallery } from "@/components/gallery";

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-24">
      {/* Hero Section */}
      <section id="hero" className="py-16 sm:py-24">
        <div className="container px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl font-bold text-center sm:text-7xl">
            Welcome to Our Fitness Center
          </h1>
          <p className="mt-4 text-lg text-center text-muted-foreground">
            Your journey to a healthier lifestyle starts here.
          </p>
          <div className="mt-8 flex justify-center">
            <Link href="#contact" className="btn-primary">
              Get Started
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 sm:py-24">
        <div className="container px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-3xl font-bold sm:text-4xl">Why Choose Us</h2>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {/* Card 1 */}
            <div className="flex flex-col items-center p-6 border rounded-lg shadow-md">
              <svg className="h-12 w-12 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              <h3 className="mt-4 text-xl font-bold">Expert Trainers</h3>
              <p className="mt-2 text-muted-foreground">
                Our certified trainers provide personalized guidance.
              </p>
            </div>
            {/* Card 2 */}
            <div className="flex flex-col items-center p-6 border rounded-lg shadow-md">
              <svg className="h-12 w-12 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <h3 className="mt-4 text-xl font-bold">State-of-the-Art Equipment</h3>
              <p className="mt-2 text-muted-foreground">
                We have the latest and greatest fitness equipment.
              </p>
            </div>
            {/* Card 3 */}
            <div className="flex flex-col items-center p-6 border rounded-lg shadow-md">
              <svg className="h-12 w-12 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20h-5v-2" />
              </svg>
              <h3 className="mt-4 text-xl font-bold">Supportive Community</h3>
              <p className="mt-2 text-muted-foreground">
                Join a community of like-minded individuals.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section id="gallery" className="py-16 sm:py-24">
        <div className="container px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-3xl font-bold sm:text-4xl">Our Facility</h2>
          <Gallery />
        </div>
      </section>

      {/* Location Section */}
      <section id="location" className="py-16 sm:py-24">
        <div className="container px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <h2 className="text-3xl font-bold">Find Us</h2>
              <p className="mt-4 text-muted-foreground">
                123 Fitness Street<br />
                Your City, ST 12345
              </p>
              <div className="mt-8">
                <Link href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
                  <Button className="gap-2">
                    <WhatsApp className="h-5 w-5" />
                    Chat on WhatsApp
                  </Button>
                </Link>
              </div>
              <div className="mt-8">
                <h3 className="text-xl font-bold">Hours</h3>
                <ul className="mt-4 space-y-2">
                  <li className="flex justify-between">
                    <span>Monday - Friday</span>
                    <span>6:00 AM - 10:00 PM</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Saturday</span>
                    <span>7:00 AM - 8:00 PM</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Sunday</span>
                    <span>8:00 AM - 6:00 PM</span>
                  </li>
                </ul>
              </div>
            </div>
            <div className="h-[400px] rounded-lg bg-muted">
              {/* Replace with your preferred map implementation */}
              <div className="flex h-full items-center justify-center">
                <Link 
                  href="https://maps.google.com" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-primary hover:underline"
                >
                  View on Google Maps
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="bg-primary py-16 text-primary-foreground sm:py-24">
        <div className="container px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold sm:text-4xl">Start Your Fitness Journey Today</h2>
          <p className="mt-4 text-lg sm:text-xl">
            Get in touch with us and transform your life with our expert guidance
          </p>
          <div className="mt-8">
            <Link href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="secondary" className="gap-2">
                <WhatsApp className="h-5 w-5" />
                Contact Now on WhatsApp
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}

