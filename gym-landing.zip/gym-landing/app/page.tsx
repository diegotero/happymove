import Image from "next/image"
import Link from "next/link"
import { MapPin, Phone, PhoneIcon as WhatsApp, Clock, ArrowRight } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/header"
import { Testimonials } from "@/components/testimonials"
import { Gallery } from "@/components/gallery"
import { LeaderSection } from "@/components/leader-section"
import { ServicesSection } from "@/components/services-section"
import { FloatingWhatsApp } from "@/components/floating-whatsapp"

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="relative bg-black">
        <div className="absolute inset-0">
          <Image
            src="/placeholder.svg?height=800&width=1600"
            alt="Interior del estudio"
            width={1600}
            height={800}
            className="h-full w-full object-cover opacity-60"
          />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 sm:py-32 lg:px-8 lg:py-40">
          <div className="text-center">
            <Image
              src="/happy_move_vertical.pdf.png"
              alt="HappyMove Logo"
              width={300}
              height={150}
              className="mx-auto mb-8 h-24 w-auto"
              priority
            />
            <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl md:text-6xl lg:text-7xl">
              Estudio de entrenamiento
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-xl text-gray-300 sm:text-2xl">
              Entrenamiento profesional, equipamiento de última generación y programas personalizados para ayudarte a alcanzar tus objetivos
            </p>
            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Link href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="w-full sm:w-auto bg-[#9146ff] hover:bg-[#9146ff]/90 text-white">
                  <WhatsApp className="mr-2 h-5 w-5" />
                  Contactanos Ahora
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="w-full bg-white/10 text-white hover:bg-white/20 sm:w-auto">
                Ver Horarios
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-12 sm:py-16 md:py-24">
        <div className="container">
          <h2 className="mb-8 text-center text-2xl font-bold sm:text-3xl md:text-4xl">¿Por qué elegirnos?</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardContent className="flex flex-col items-center p-6 text-center">
                <Clock className="h-12 w-12 text-[#9146ff]" />
                <h3 className="mt-4 text-xl font-bold">Horarios Flexibles</h3>
                <p className="mt-2 text-sm text-muted-foreground">Abierto de 6:00 AM a 10:00 PM todos los días</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="flex flex-col items-center p-6 text-center">
                <MapPin className="h-12 w-12 text-[#9146ff]" />
                <h3 className="mt-4 text-xl font-bold">Ubicación Privilegiada</h3>
                <p className="mt-2 text-sm text-muted-foreground">Fácil acceso y estacionamiento gratuito</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="flex flex-col items-center p-6 text-center">
                <Phone className="h-12 w-12 text-[#9146ff]" />
                <h3 className="mt-4 text-xl font-bold">Entrenamiento Personalizado</h3>
                <p className="mt-2 text-sm text-muted-foreground">Entrenadores expertos para guiar tu progreso</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <LeaderSection />
      <ServicesSection />

      {/* Gallery Section */}
      <section id="gallery" className="py-12 sm:py-16 md:py-24">
        <div className="container">
          <h2 className="mb-8 text-center text-2xl font-bold sm:text-3xl md:text-4xl">Nuestras Instalaciones</h2>
          <Gallery />
        </div>
      </section>

      <Testimonials />

      {/* Location Section */}
      <section id="location" className="py-12 sm:py-16 md:py-24">
        <div className="container">
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <h2 className="text-2xl font-bold sm:text-3xl">Encontranos</h2>
              <p className="mt-4 text-muted-foreground">
                123 Calle Fitness<br />
                Tu Ciudad, CP 12345
              </p>
              <div className="mt-6">
                <Link href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
                  <Button className="gap-2 bg-[#9146ff] hover:bg-[#9146ff]/90 text-white">
                    <WhatsApp className="h-5 w-5" />
                    Chateá por WhatsApp
                  </Button>
                </Link>
              </div>
              <div className="mt-8">
                <h3 className="text-xl font-bold">Horarios</h3>
                <ul className="mt-4 space-y-2 text-sm">
                  <li className="flex justify-between">
                    <span>Lunes - Viernes</span>
                    <span>6:00 AM - 10:00 PM</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Sábado</span>
                    <span>7:00 AM - 8:00 PM</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Domingo</span>
                    <span>8:00 AM - 6:00 PM</span>
                  </li>
                </ul>
              </div>
            </div>
            <div className="h-[300px] sm:h-[400px] rounded-lg bg-muted">
              <div className="flex h-full items-center justify-center">
                <Link 
                  href="https://maps.google.com" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-[#9146ff] hover:underline"
                >
                  Ver en Google Maps
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="bg-black py-12 text-white sm:py-16 md:py-24">
        <div className="container text-center">
          <h2 className="text-2xl font-bold sm:text-3xl md:text-4xl">Comenzá Tu Transformación Hoy</h2>
          <p className="mt-4 text-base sm:text-lg md:text-xl">
            Contactanos y transformá tu vida con nuestra guía experta
          </p>
          <div className="mt-8">
            <Link href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="gap-2 bg-[#9146ff] hover:bg-[#9146ff]/90 text-white">
                <WhatsApp className="h-5 w-5" />
                Contactanos Ahora por WhatsApp
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <FloatingWhatsApp />
    </div>
  )
}

