<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuestro Gimnasio</title>
    <style>
        body {
            font-family: sans-serif;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .cta-button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Bienvenido a Nuestro Gimnasio</h1>
        <p>Te ayudamos a lograr tus objetivos de fitness.</p>

        <h2>¿Por qué elegirnos?</h2>
        <p>Ofrecemos una variedad de servicios para ayudarte a alcanzar tus metas, incluyendo:</p>
        <ul>
            <li>Horarios Flexibles</li>
            <li>Ubicación Privilegiada</li>
            <li>Entrenamiento Personalizado</li>
        </ul>

        <h2>Nuestras Instalaciones</h2>
        <p>Contamos con instalaciones de última generación para que puedas entrenar cómodamente.</p>

        {/* Testimonials Section */}
        <Testimonials />

        <h2>Encontranos</h2>
        <p>Estamos ubicados en [Dirección].</p>

        <a href="#" class="cta-button">Contactanos Ahora</a>
        <a href="#" class="cta-button">Chateá por WhatsApp</a>

        <p>Comenzá Tu Transformación Hoy</p>

        <p>Contactanos y transformá tu vida con nuestra guía experta</p>

        <a href="#" class="cta-button">Contactanos Ahora por WhatsApp</a>

    </div>
</body>
</html>

