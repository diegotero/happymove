import { Button } from '@chakra-ui/react';
import { Link } from 'next/link';
import { WhatsApp } from '../components/icons';

function Hero() {
  return (
    <section className="bg-gradient-to-r from-blue-500 to-purple-500 text-white py-20">
      <div className="container mx-auto text-center">
        <h1 className="text-5xl font-bold mb-4">Welcome to Our Website</h1>
        <p className="text-lg mb-8">This is a sample website built with Next.js and Chakra UI.</p>
        <Link href="#contact" className="mt-8">
          <Button size="lg" className="w-full sm:w-auto">
            Get Started
          </Button>
        </Link>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="bg-gray-100 py-12">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-bold mb-4">Contact Us</h2>
        <p className="text-lg mb-8">We'd love to hear from you!</p>
        <Link href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
          <Button size="lg" variant="secondary" className="gap-2">
            <WhatsApp className="h-5 w-5" />
            Contact Now on WhatsApp
          </Button>
        </Link>
      </div>
    </section>
  );
}

export default function Home() {
  return (
    <div>
      <Hero />
      <CTA />
    </div>
  );
}

