import './globals.css'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'HappyMove - Estudio de entrenamiento',
  description: 'Entrenamiento profesional, equipamiento de última generación y programas personalizados para ayudarte a alcanzar tus objetivos fitness',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <body className={inter.className}>{children}</body>
  )
}

