'use client'

import { useState } from "react"
import Image from "next/image"
import { Dialog, DialogContent } from "@/components/ui/dialog"

const galleryImages = [
  "/placeholder.svg?height=600&width=800&text=Gym1",
  "/placeholder.svg?height=600&width=800&text=Gym2",
  "/placeholder.svg?height=600&width=800&text=Gym3",
  "/placeholder.svg?height=600&width=800&text=Gym4",
  "/placeholder.svg?height=600&width=800&text=Gym5",
  "/placeholder.svg?height=600&width=800&text=Gym6",
]

export function Gallery() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)

  return (
    <>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {galleryImages.map((src, i) => (
          <div key={i} className="aspect-w-4 aspect-h-3">
            <Image
              src={src}
              alt={`Gym facility ${i + 1}`}
              layout="fill"
              objectFit="cover"
              className="rounded-lg cursor-pointer transition-transform hover:scale-105"
              onClick={() => setSelectedImage(src)}
            />
          </div>
        ))}
      </div>
      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-3xl p-0">
          {selectedImage && (
            <div className="relative aspect-w-16 aspect-h-9">
              <Image
                src={selectedImage}
                alt="Selected gym facility"
                layout="fill"
                objectFit="contain"
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}

