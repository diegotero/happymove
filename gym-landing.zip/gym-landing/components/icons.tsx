import { PhoneIcon } from 'lucide-react'

export const WhatsApp = PhoneIcon

