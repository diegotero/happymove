import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Menu } from "lucide-react"

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <Link href="/" className="flex items-center space-x-2">
          <Image
            src="/placeholder.svg?height=32&width=32&text=Logo"
            alt="Gym Logo"
            width={32}
            height={32}
            className="rounded-sm"
          />
          <span className="text-xl font-bold">FitZone</span>
        </Link>
        <nav className="ml-auto hidden md:flex gap-6">
          <Link href="#features" className="text-sm font-medium hover:underline underline-offset-4">
            Features
          </Link>
          <Link href="#gallery" className="text-sm font-medium hover:underline underline-offset-4">
            Gallery
          </Link>
          <Link href="#location" className="text-sm font-medium hover:underline underline-offset-4">
            Location
          </Link>
        </nav>
        <Button asChild className="ml-4 hidden md:inline-flex">
          <Link href="#contact">Join Now</Link>
        </Button>
        <Button variant="ghost" size="icon" className="ml-auto md:hidden">
          <Menu className="h-6 w-6" />
          <span className="sr-only">Open menu</span>
        </Button>
      </div>
    </header>
  )
}

