import Link from "next/link"
import Image from "next/image"
import { Menu } from 'lucide-react'
import { Button } from "@/components/ui/button"
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet"

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-20 items-center">
        <Link href="/" className="flex items-center">
          <Image
            src="/happy_move_vertical.png"
            alt="HappyMove Logo"
            width={120}
            height={60}
            className="h-12 w-auto"
            priority
          />
        </Link>
        <nav className="ml-auto hidden gap-6 md:flex">
          <Link href="#features" className="text-sm font-medium hover:text-highlight">
            Servicios
          </Link>
          <Link href="#gallery" className="text-sm font-medium hover:text-highlight">
            Galería
          </Link>
          <Link href="#location" className="text-sm font-medium hover:text-highlight">
            Ubicación
          </Link>
        </nav>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="ml-auto md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Abrir menú</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right">
            <div className="mt-2 mb-8">
              <Image
                src="/happy_move_vertical.png"
                alt="HappyMove Logo"
                width={100}
                height={50}
                className="h-10 w-auto"
              />
            </div>
            <nav className="flex flex-col gap-4">
              <Link href="#features" className="text-sm font-medium hover:text-highlight">
                Servicios
              </Link>
              <Link href="#gallery" className="text-sm font-medium hover:text-highlight">
                Galería
              </Link>
              <Link href="#location" className="text-sm font-medium hover:text-highlight">
                Ubicación
              </Link>
            </nav>
          </SheetContent>
        </Sheet>
        <Button 
          asChild 
          className="ml-4 bg-[#9146ff] hover:bg-[#9146ff]/90 text-white"
        >
          <Link href="#contact">Empieza Ahora</Link>
        </Button>
      </div>
    </header>
  )
}

