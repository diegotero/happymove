import Link from "next/link"
import Image from "next/image"
import { Menu } from 'lucide-react'
import { Button } from "@/components/ui/button"
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet"

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <Link href="/" className="flex items-center space-x-2">
          <Image
            src="/placeholder.svg?height=32&width=32&text=Logo"
            alt="Gym Logo"
            width={32}
            height={32}
            className="rounded-sm"
          />
          <span className="text-xl font-bold">FitZone</span>
        </Link>
        <nav className="ml-auto hidden gap-6 md:flex">
          <Link href="#features" className="text-sm font-medium hover:underline underline-offset-4">
            Features
          </Link>
          <Link href="#gallery" className="text-sm font-medium hover:underline underline-offset-4">
            Gallery
          </Link>
          <Link href="#location" className="text-sm font-medium hover:underline underline-offset-4">
            Location
          </Link>
        </nav>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="ml-auto md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right">
            <nav className="flex flex-col gap-4">
              <Link href="#features" className="text-sm font-medium hover:underline underline-offset-4">
                Features
              </Link>
              <Link href="#gallery" className="text-sm font-medium hover:underline underline-offset-4">
                Gallery
              </Link>
              <Link href="#location" className="text-sm font-medium hover:underline underline-offset-4">
                Location
              </Link>
            </nav>
          </SheetContent>
        </Sheet>
        <Button asChild className="ml-4">
          <Link href="#contact">Join Now</Link>
        </Button>
      </div>
    </header>
  )
}

