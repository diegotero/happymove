import Link from "next/link"
import Image from "next/image"
import { Menu } from 'lucide-react'
import { Button } from "@/components/ui/button"
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet"

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <Link href="/" className="flex items-center space-x-2">
          <Image
            src="/happymove-logo.png"
            alt="HappyMove Logo"
            width={40}
            height={40}
            className="rounded-sm"
          />
          <span className="text-xl font-bold">HappyMove</span>
        </Link>
        <nav className="ml-auto hidden gap-6 md:flex">
          <Link href="#features" className="text-sm font-medium hover:text-highlight">
            Features
          </Link>
          <Link href="#gallery" className="text-sm font-medium hover:text-highlight">
            Gallery
          </Link>
          <Link href="#location" className="text-sm font-medium hover:text-highlight">
            Location
          </Link>
        </nav>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="ml-auto md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right">
            <nav className="flex flex-col gap-4">
              <Link href="#features" className="text-sm font-medium hover:text-highlight">
                Features
              </Link>
              <Link href="#gallery" className="text-sm font-medium hover:text-highlight">
                Gallery
              </Link>
              <Link href="#location" className="text-sm font-medium hover:text-highlight">
                Location
              </Link>
            </nav>
          </SheetContent>
        </Sheet>
        <Button asChild className="ml-4 bg-highlight hover:bg-highlight/90 text-white">
          <Link href="#contact">Empieza Ahora</Link>
        </Button>
      </div>
    </header>
  )
}

