import Link from "next/link"
import { Button } from "@/components/ui/button"

function MyComponent() {
  return (
    <div>
      {/* rest of the component */}
      <Link href="#contact" className="ml-4">
        <Button>Join Now</Button>
      </Link>
    </div>
  )
}

export default MyComponent;

