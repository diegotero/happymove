\`\`\`html
<!DOCTYPE html>
<html>
<head>
<title>Image Update</title>
</head>
<body>

<img src="/happy_move_vertical.pdf.png" alt="Happy Move Vertical">

</body>
</html>
\`\`\`

