import Link from 'next/link';
import Image from 'next/image';

const Header = () => {
  return (
    <header className="bg-gray-800 py-4">
      <nav className="container mx-auto flex justify-between items-center">
        <Link href="/" className="flex items-center space-x-2">
          <Image
            src="/happy_move_vertical.pdf.png"
            alt="HappyMove Logo"
            width={80}
            height={40}
            className="h-10 w-20 object-contain"
          />
        </Link>
        {/* Navigation links will go here */}
      </nav>
    </header>
  );
};

export default Header;

