import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function ServicesSection() {
  return (
    <section className="py-12 sm:py-16 md:py-24">
      <div className="container">
        <h2 className="text-3xl font-bold text-center mb-12">Nuestros Servicios</h2>
        <div className="grid gap-8 md:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="text-[#9146ff]">Entrenamiento Funcional</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Clases personalizadas en grupo que se adaptan a tus necesidades y objetivos. Mejora tu fuerza, flexibilidad y resistencia en un ambiente motivador y de apoyo mutuo.</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-[#9146ff]">Planes de Entrenamiento a Distancia</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Programas de ejercicios diseñados específicamente para ti, que puedes realizar desde casa o donde te encuentres. Incluye seguimiento y ajustes periódicos para garantizar tu progreso.</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-[#9146ff]">Planes para Running y Trail</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Ya sea que estés preparándote para tu primera carrera o buscando mejorar tus tiempos, nuestros planes te ayudarán a alcanzar tus metas en running y trail running de manera segura y eficiente.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}

