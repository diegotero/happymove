import Link from "next/link"
import { MapPin, PhoneIcon as WhatsApp, ArrowRight } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export function LocationSection() {
  const weekdayHours = [
    {
      day: "Lunes",
      hours: [
        "7:00 a.m. – 10:00 a.m.",
        "3:00 p.m. – 8:00 p.m."
      ]
    },
    {
      day: "Martes",
      hours: [
        "7:00 a.m. – 10:00 a.m.",
        "3:00 p.m. – 8:00 p.m."
      ]
    },
    {
      day: "Miércoles",
      hours: [
        "7:00 a.m. – 10:00 a.m.",
        "3:00 p.m. – 8:00 p.m."
      ]
    },
    {
      day: "Jueves",
      hours: [
        "7:00 a.m. – 10:00 a.m.",
        "3:00 p.m. – 8:00 p.m."
      ]
    },
    {
      day: "Viernes",
      hours: [
        "7:00 a.m. – 10:00 a.m.",
        "3:00 p.m. – 8:00 p.m."
      ]
    }
  ]

  return (
    <section id="location" className="py-20 sm:py-32 bg-gray-50">
      <div className="container">
        <div className="grid gap-8 lg:grid-cols-2">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 mb-6">Encontranos</h2>
            <p className="text-lg text-gray-600 mb-8">
              123 Calle Fitness<br />
              Tu Ciudad, CP 12345
            </p>
            <div className="mb-12">
              <Link href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
                <Button className="gap-2 bg-[#6C38FF] hover:bg-[#5B2FD9] text-white">
                  <WhatsApp className="h-5 w-5" />
                  Chateá por WhatsApp
                </Button>
              </Link>
            </div>
            <Card className="bg-white shadow-lg">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-6">Horarios de atención</h3>
                <div className="space-y-4">
                  {weekdayHours.map((schedule, index) => (
                    <div key={index} className="border-b border-gray-200 pb-4 last:border-0 last:pb-0">
                      <div className="flex justify-between items-start">
                        <span className="font-medium text-gray-900">{schedule.day}</span>
                        <div className="text-right">
                          {schedule.hours.map((time, timeIndex) => (
                            <div key={timeIndex} className="text-gray-600">
                              {time}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          <div className="h-[400px] rounded-lg bg-gray-200 overflow-hidden">
            <div className="flex h-full items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200">
              <Link 
                href="https://maps.google.com" 
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-[#6C38FF] hover:text-[#5B2FD9] transition-colors"
              >
                <MapPin className="h-6 w-6" />
                <span className="font-medium">Ver en Google Maps</span>
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

