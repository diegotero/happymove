import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"

const testimonials = [
  {
    name: "Sarah Johnson",
    role: "Entusiasta del fitness",
    content: "HappyMove ha transformado completamente mi viaje fitness. ¡Los entrenadores son excepcionales y el ambiente es motivador!",
    image: "/placeholder.svg?height=100&width=100&text=SJ"
  },
  {
    name: "Mike Thompson",
    role: "Corredor de maratón",
    content: "He estado en muchos gimnasios, pero HappyMove se destaca. El equipamiento es de primera y la comunidad es increíblemente solidaria.",
    image: "/placeholder.svg?height=100&width=100&text=MT"
  },
  {
    name: "Emily Chen",
    role: "Instructora de yoga",
    content: "Como instructora de yoga, aprecio el ambiente limpio y tranquilo que HappyMove proporciona. Es perfecto para todo tipo de entrenamientos.",
    image: "/placeholder.svg?height=100&width=100&text=EC"
  }
]

export function Testimonials() {
  return (
    <section className="bg-muted py-12 sm:py-16 md:py-24">
      <div className="container">
        <h2 className="mb-8 text-center text-2xl font-bold sm:text-3xl md:text-4xl">Lo que dicen nuestros miembros</h2>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <Card key={index}>
              <CardContent className="flex flex-col items-center p-6 text-center">
                <Image
                  src={testimonial.image}
                  alt={testimonial.name}
                  width={80}
                  height={80}
                  className="rounded-full"
                />
                <h3 className="mt-4 text-lg font-bold">{testimonial.name}</h3>
                <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                <p className="mt-4 text-sm text-muted-foreground">{testimonial.content}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

