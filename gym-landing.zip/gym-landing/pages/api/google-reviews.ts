import { NextApiRequest, NextApiResponse } from 'next'

const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY
const LOCATION_ID = '2703371837824727496'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const response = await fetch(
        `https://mybusiness.googleapis.com/v4/accounts/AIzaSyAfFFt6jBQUk16cTw0EeVD8UaOh_vLjCYI/locations/${LOCATION_ID}/reviews`,
        {
          headers: {
            Authorization: `Bearer ${GOOGLE_API_KEY}`,
          },
        }
      )

      if (!response.ok) {
        throw new Error('Failed to fetch reviews')
      }

      const data = await response.json()
      res.status(200).json(data)
    } catch (error) {
      console.error('Error fetching reviews:', error)
      res.status(500).json({ error: 'Error fetching reviews' })
    }
  } else {
    res.setHeader('Allow', ['GET'])
    res.status(405).end(`Method ${req.method} Not Allowed`)
  }
}

