import { NextApiRequest, NextApiResponse } from 'next'
import { getSession } from "next-auth/react"

const LOCATION_ID = process.env.GOOGLE_LOCATION_ID

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getSession({ req })

  if (!session || !session.accessToken) {
    return res.status(401).json({ error: 'Not authenticated' })
  }

  if (req.method === 'GET') {
    try {
      const response = await fetch(
        `https://mybusiness.googleapis.com/v4/accounts/AIzaSyAfFFt6jBQUk16cTw0EeVD8UaOh_vLjCYI/locations/${LOCATION_ID}/reviews`,
        {
          headers: {
            Authorization: `Bearer ${session.accessToken}`,
          },
        }
      )

      if (!response.ok) {
        throw new Error('Failed to fetch reviews')
      }

      const data = await response.json()
      res.status(200).json(data)
    } catch (error) {
      console.error('Error fetching reviews:', error)
      res.status(500).json({ error: 'Error fetching reviews' })
    }
  } else {
    res.setHeader('Allow', ['GET'])
    res.status(405).end(`Method ${req.method} Not Allowed`)
  }
}

